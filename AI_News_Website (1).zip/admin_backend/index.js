
const expressAdmin = require("express");
const corsAdmin = require("cors");
const session = require("express-session");
const bodyParser = require("body-parser");
const dotenvAdmin = require("dotenv");

dotenvAdmin.config();
const adminApp = expressAdmin();
adminApp.use(corsAdmin());
adminApp.use(bodyParser.json());
adminApp.use(
  session({
    secret: "secret",
    resave: false,
    saveUninitialized: true,
  })
);

const ADMIN_USERNAME = "Ayesha";
const ADMIN_PASSWORD = "ayesha";

adminApp.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    req.session.user = username;
    return res.json({ success: true });
  }
  res.status(401).json({ success: false });
});

adminApp.listen(5001, () => console.log("Admin backend running on 5001"));
