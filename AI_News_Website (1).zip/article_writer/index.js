
const { Configuration, OpenAIApi } = require("openai");
const dotenvWriter = require("dotenv");
dotenvWriter.config();

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

async function generateArticle(topic) {
  const completion = await openai.createChatCompletion({
    model: "gpt-4",
    messages: [
      {
        role: "user",
        content: `Write an SEO-optimized news article about: ${topic}`,
      },
    ],
  });
  return completion.data.choices[0].message.content;
}

module.exports = { generateArticle };
