
const cron = require("node-cron");
const { generateArticle } = require("../article_writer/index");
const fs = require("fs");
const path = require("path");

cron.schedule("0 * * * *", async () => {
  const topic = "Latest trending topic";
  const article = await generateArticle(topic);
  const articlePath = path.join(__dirname, `../articles/article_${Date.now()}.txt`);
  fs.writeFileSync(articlePath, article);
  console.log("Article saved:", articlePath);
});
