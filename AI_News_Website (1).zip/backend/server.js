
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const axios = require("axios");
const slugify = require("slugify");
const googleTrends = require("google-trends-api");

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.get("/trending", async (req, res) => {
  try {
    const results = await googleTrends.dailyTrends({ geo: "US" });
    res.json(JSON.parse(results));
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch trends" });
  }
});

app.listen(5000, () => console.log("Backend running on port 5000"));
